package com.project.springboothotelproject.enitites;

// Enum representing different hotel types
public enum HotelType {
    TWO_STAR,
    THREE_STAR,
    FOUR_STAR,
    FIVE_STAR;
}
